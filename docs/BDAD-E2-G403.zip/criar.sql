PRAGMA foreign_keys=ON;

DROP TABLE IF EXISTS Pessoa;
DROP TABLE IF EXISTS Cliente;
DROP TABLE IF EXISTS Agente;
DROP TABLE IF EXISTS Viagem;
DROP TABLE IF EXISTS Pais;
DROP TABLE IF EXISTS Cliente_Viagem_Agente;
DROP TABLE IF EXISTS Deslocacao;
DROP TABLE IF EXISTS Ordem_Ida;
DROP TABLE IF EXISTS Ordem_Regresso;
DROP TABLE IF EXISTS Aviao;
DROP TABLE IF EXISTS Barco;
DROP TABLE IF EXISTS Autocarro;
DROP TABLE IF EXISTS Comboio;
DROP TABLE IF EXISTS Hotel;
DROP TABLE IF EXISTS Quarto;
DROP TABLE IF EXISTS Viagem_Estadia;
DROP TABLE IF EXISTS Pagamento;
DROP TABLE IF EXISTS Transferencia_Bancaria;
DROP TABLE IF EXISTS Numerario;
DROP TABLE IF EXISTS Cheque;
DROP TABLE IF EXISTS Cartao;
DROP TABLE IF EXISTS Mbway;

CREATE TABLE Pessoa (
    id INTEGER,
    nif INTEGER UNIQUE NOT NULL,
    nome TEXT NOT NULL,
    telefone INTEGER NOT NULL,
    CONSTRAINT PESSOA_PK PRIMARY KEY (id)
);

CREATE TABLE Cliente (
    id INTEGER,
    morada TEXT NOT NULL,
    codPostal TEXT NOT NULL,
    CONSTRAINT CLIENTE_PK PRIMARY KEY (id),
    CONSTRAINT CLIENTE_PESSOA_FK FOREIGN KEY (id) REFERENCES Pessoa(id)
);

CREATE TABLE Agente (
    id INTEGER,
    CONSTRAINT AGENTE_PK PRIMARY KEY (id),
    CONSTRAINT AGENTE_PESSOA_FK FOREIGN KEY (id) REFERENCES Pessoa(id)
);

CREATE TABLE Pais (
    nome TEXT NOT NULL,
    PRIMARY KEY (nome)
);

CREATE TABLE Viagem (
    id INTEGER,
    moradaOrigem TEXT NOT NULL,
    moradaDestino TEXT NOT NULL,
    numViajantes INTEGER CHECK (numViajantes > 0),
    dataInicio DATE NOT NULL,
    dataFim DATE NOT NULL,
    tipoDeViagem TEXT NOT NULL,
    preco INTEGER CHECK (preco > 0),
    desconto INTEGER,
    precoFinal INTEGER CHECK (precoFinal > 0),
    paisOrigem TEXT NOT NULL,
    paisDestino TEXT NOT NULL,
    CONSTRAINT VIAGEM_PK PRIMARY KEY (id),
    CONSTRAINT VIAGEM_PAIS_ORIGEM_FK FOREIGN KEY (paisOrigem) REFERENCES Pais(nome),
    CONSTRAINT VIAGEM_PAIS_DESTINO_FK FOREIGN KEY (paisDestino) REFERENCES Pais(nome),
    CONSTRAINT PRECO_CHECK CHECK (precoFinal <= preco),
    CONSTRAINT DATE_CHECK CHECK (dataFim >= dataInicio),
    CONSTRAINT DESCONTO_CHECK CHECK (desconto < 100 AND desconto >= 0)
);

CREATE TABLE Cliente_Viagem_Agente (
    idCliente INTEGER NOT NULL,
    idViagem INTEGER NOT NULL,
    idAgente INTEGER NOT NULL,
    CONSTRAINT CLIENTE_VIAGEM_AGENTE_PK PRIMARY KEY (idCliente, idViagem, idAgente),
    CONSTRAINT CLIENTE_FK FOREIGN KEY (idCliente) REFERENCES Cliente(id),
    CONSTRAINT VIAGEM_FK FOREIGN KEY (idViagem) REFERENCES Viagem(id),
    CONSTRAINT AGENTE_FK FOREIGN KEY (idAgente) REFERENCES Agente(id)
);

CREATE TABLE Deslocacao (
    id INTEGER,
    duracaoDesloc TEXT NOT NULL,
    moradaOrigem TEXT NOT NULL,
    moradaDestino TEXT NOT NULL,
    dataPartida DATE NOT NULL,
    horaPartida TEXT NOT NULL,
    numLugares INTEGER CHECK (numLugares > 0),
    paisOrigem TEXT NOT NULL,
    paisDestino TEXT NOT NULL,
    CONSTRAINT DESLOCACAO_PK PRIMARY KEY (id),
    CONSTRAINT DESLOCACAO_PAIS_FK FOREIGN KEY (paisOrigem) REFERENCES Pais(nome),
    CONSTRAINT DESLOCACAO_PAIS_FK FOREIGN KEY (paisDestino) REFERENCES Pais(nome)
);

CREATE TABLE Ordem_Ida (
    idViagem INTEGER,
    idDeslocacao INTEGER,
    ordem INTEGER CHECK (ordem > 0),
    CONSTRAINT ORDEM_IDA_PK PRIMARY KEY (idViagem, idDeslocacao),
    CONSTRAINT ORDEM_IDA_VIAGEM_FK FOREIGN KEY (idViagem) REFERENCES Viagem(id),
    CONSTRAINT ORDEM_IDA_DESLOCACAO_FK FOREIGN KEY (idDeslocacao) REFERENCES Deslocacao(id)
);

CREATE TABLE Ordem_Regresso (
    idViagem INTEGER,
    idDeslocacao INTEGER,
    ordem INTEGER CHECK (ordem > 0),
    CONSTRAINT ORDEM_REGRESSO_PK PRIMARY KEY (idViagem, idDeslocacao),
    CONSTRAINT ORDEM_REGRESSO_VIAGEM_FK FOREIGN KEY (idViagem) REFERENCES Viagem(id),
    CONSTRAINT ORDEM_REGRESSO_DESLOCACAO_FK FOREIGN KEY (idDeslocacao) REFERENCES Deslocacao(id)
);

CREATE TABLE Aviao (
    idDeslocacao INTEGER,
    aeroporto TEXT NOT NULL,
    CONSTRAINT AVIAO_PK PRIMARY KEY (idDeslocacao),
    CONSTRAINT AVIAO_DESLOCACAO_FK FOREIGN KEY (idDeslocacao) REFERENCES Deslocacao(id)
);

CREATE TABLE Barco (
    idDeslocacao INTEGER,
    porto TEXT NOT NULL,
    CONSTRAINT BARCO_PK PRIMARY KEY (idDeslocacao),
    CONSTRAINT AVIAO_DESLOCACAO_FK FOREIGN KEY (idDeslocacao) REFERENCES Deslocacao(id)
);

CREATE TABLE Autocarro (
    idDeslocacao INTEGER,
    estacao TEXT NOT NULL,
    CONSTRAINT AUTOCARRO_PK PRIMARY KEY (idDeslocacao),
    CONSTRAINT AVIAO_DESLOCACAO_FK FOREIGN KEY (idDeslocacao) REFERENCES Deslocacao(id)
);

CREATE TABLE Comboio (
    idDeslocacao INTEGER,
    estacao TEXT NOT NULL,
    CONSTRAINT COMBOIO_PK PRIMARY KEY (idDeslocacao),
    CONSTRAINT AVIAO_DESLOCACAO_FK FOREIGN KEY (idDeslocacao) REFERENCES Deslocacao(id)
);

CREATE TABLE Hotel (
    nome TEXT NOT NULL,
    morada TEXT NOT NULL,
    codPostal TEXT,
    telefone TEXT NOT NULL,
    CONSTRAINT HOTEL_PK PRIMARY KEY(nome, morada)
);

CREATE TABLE Quarto (
    idQuarto INTEGER,
    andar INTEGER,
    tipo TEXT NOT NULL,
    nomeHotel TEXT NOT NULL,
    morada TEXT,
    CONSTRAINT QUARTO_PK PRIMARY KEY (idQuarto, nomeHotel, morada),
    CONSTRAINT QUARTO_HOTEL_FK FOREIGN KEY (nomeHotel, morada) REFERENCES Hotel(nome, morada)
);

CREATE TABLE Viagem_Estadia (
    idViagem INTEGER NOT NULL,
    idQuarto INTEGER NOT NULL,
    nomeHotel TEXT NOT NULL,
    morada TEXT NOT NULL,
    CONSTRAINT VIAGEM_ESTADIA_PK PRIMARY KEY(idViagem, nomeHotel, morada, idQuarto),
    CONSTRAINT VIAGEM_ESTADIA_VIAGEM_FK FOREIGN KEY (idViagem) REFERENCES Viagem(id),
    CONSTRAINT VIAGEM_ESTADIA_QUARTO_FK FOREIGN KEY (idQuarto, nomeHotel, morada) REFERENCES Quarto(idQuarto, nomeHotel, morada)
);

CREATE TABLE Pagamento (
    id INTEGER,
    data DATE NOT NULL,
    hora TEXT NOT NULL,
    idCliente INTEGER NOT NULL,
    idViagem INTEGER NOT NULL,
    CONSTRAINT PAGAMENTO_PK PRIMARY KEY (id),
    CONSTRAINT PAGAMENTO_CLIENTE_FK FOREIGN KEY (idCliente) REFERENCES Cliente(id),
    CONSTRAINT PAGAMENTO_VIAGEM_FK FOREIGN KEY (idViagem) REFERENCES Viagem(id)
);

CREATE TABLE Transferencia_Bancaria (
    idPagamento INTEGER,
    IBAN TEXT NOT NULL,
    CONSTRAINT TRANSFERENCIA_BANCARIA_PK PRIMARY KEY (idPagamento),
    CONSTRAINT TRANSFERENCIA_BANCARIA_PAGAMENTO_FK FOREIGN KEY (idPagamento) REFERENCES Pagamento(id)
);

CREATE TABLE Numerario (
    idPagamento INTEGER,
    troco INTEGER,
    CONSTRAINT NUMERARIO_PK PRIMARY KEY (idPagamento),
    CONSTRAINT TRANSFERENCIA_BANCARIA_PAGAMENTO_FK FOREIGN KEY (idPagamento) REFERENCES Pagamento(id)
);

CREATE TABLE Cheque (
    idPagamento INTEGER,
    nome TEXT NOT NULL,
    CONSTRAINT CHEQUE_PK PRIMARY KEY (idPagamento),
    CONSTRAINT TRANSFERENCIA_BANCARIA_PAGAMENTO_FK FOREIGN KEY (idPagamento) REFERENCES Pagamento(id)
);

CREATE TABLE Cartao (
    idPagamento INTEGER,
    numCartao INTEGER NOT NULL,
    CONSTRAINT CARTAO_PK PRIMARY KEY (idPagamento),
    CONSTRAINT TRANSFERENCIA_BANCARIA_PAGAMENTO_FK FOREIGN KEY (idPagamento) REFERENCES Pagamento(id)
);

CREATE TABLE Mbway (
    idPagamento INTEGER,
    numTelefone INTEGER NOT NULL,
    CONSTRAINT MBWAY_PK PRIMARY KEY (idPagamento),
    CONSTRAINT TRANSFERENCIA_BANCARIA_PAGAMENTO_FK FOREIGN KEY (idPagamento) REFERENCES Pagamento(id)
);
