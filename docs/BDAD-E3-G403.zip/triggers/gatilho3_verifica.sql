SELECT 'TRIGGER 3';

SELECT * FROM Viagem;
UPDATE DESLOCACAO SET dataPartida = "2021-05-16" WHERE idDeslocacao = 1;
SELECT * FROM Viagem;

SELECT * FROM Viagem;
UPDATE DESLOCACAO SET dataPartida = "2021-05-22" WHERE idDeslocacao = 1;
SELECT * FROM Viagem;
